<?php
include 'db_connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$name = $_POST['name'];
$price = $_POST['price'];
$stmt = $conn->prepare("INSERT INTO cart (product_name, price) VALUES (?, ?)");
$stmt->bind_param("sd", $name, $price);
if ($stmt->execute()) {
echo "Product added to cart successfully!";
} else {
echo "Error: " . $stmt->error;
}
$stmt->close();
$conn->close();
}
?>
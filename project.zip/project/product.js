let cart = [];
function addToCart(productName, productPrice) {
let product = { name: productName, price: productPrice };
cart.push(product);
alert(`${productName} added to cart!`);
updateCartDatabase(productName, productPrice);
}
function updateCartDatabase(productName, productPrice) {
fetch('add_to_cart.php', {
method: 'POST',
headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
body: `name=${productName}&price=${productPrice}`
}).then(response => response.text())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));
}